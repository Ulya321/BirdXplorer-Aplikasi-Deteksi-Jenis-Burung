package com.example.birdxplorer;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.example.birdxplorer.ml.BirdType;
import org.tensorflow.lite.support.image.TensorImage;
import org.tensorflow.lite.support.label.Category;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final int REQUEST_IMAGE_CAPTURE = 1;

    Button btLoadImage;
    Button btTakePhoto;
    TextView tvResult;
    ImageView ivAddImage;
    ActivityResultLauncher<String> mGetContent;
    ActivityResultLauncher<Intent> mTakePhoto;
    Uri photoUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (checkPermissions()) {
            setupComponents();
        } else {
            requestPermissions();
        }
    }

    private boolean checkPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.CAMERA,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        }, PERMISSION_REQUEST_CODE);
    }

    private void setupComponents() {
        ivAddImage = findViewById(R.id.iv_add_image);
        tvResult = findViewById(R.id.tv_result);
        btLoadImage = findViewById(R.id.bt_load_image);
        btTakePhoto = findViewById(R.id.bt_take_photo);

        mGetContent = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            Bitmap imageBitmap = null;
            try {
                imageBitmap = UriToBitmap(uri);
                if (imageBitmap != null) {
                    ivAddImage.setImageBitmap(imageBitmap);
                    outputGenerator(imageBitmap);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        mTakePhoto = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK) {
                Bitmap imageBitmap = null;
                try {
                    imageBitmap = UriToBitmap(photoUri);
                    if (imageBitmap != null) {
                        ivAddImage.setImageBitmap(imageBitmap);
                        outputGenerator(imageBitmap);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        btLoadImage.setOnClickListener(v -> mGetContent.launch("image/*"));

        btTakePhoto.setOnClickListener(v -> dispatchTakePictureIntent());

        tvResult.setOnClickListener(view -> {
            String query = tvResult.getText().toString();
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + query));
            startActivity(intent);
        });
    }

    private Bitmap UriToBitmap(Uri uri) throws IOException {
        return MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
    }

    private void outputGenerator(Bitmap imageBitmap) {
        try {
            BirdType model = BirdType.newInstance(this);

            TensorImage image = TensorImage.fromBitmap(imageBitmap);

            BirdType.Outputs outputs = model.process(image);
            List<Category> probability = outputs.getProbabilityAsCategoryList();

            float maxScore = 0;
            String birdLabel = "";
            for (Category category : probability) {
                if (category.getScore() > maxScore) {
                    maxScore = category.getScore();
                    birdLabel = category.getLabel();
                }
            }

            tvResult.setText(birdLabel);

            sendToServer(imageBitmap, birdLabel);

            model.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendToServer(Bitmap imageBitmap, String label) {
        File imageFile = bitmapToFile(imageBitmap, "image.jpg");
        if (imageFile == null) {
            return;
        }

        RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpeg"), imageFile);
        MultipartBody.Part body = MultipartBody.Part.createFormData("image", imageFile.getName(), requestFile);
        RequestBody labelBody = RequestBody.create(MediaType.parse("text/plain"), label);

        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<ResponseBody> call = apiService.uploadImage(body, labelBody);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(MainActivity.this, "Image uploaded successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Failed to upload image", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Error uploading image: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private File bitmapToFile(Bitmap bitmap, String fileName) {
        File file = new File(getCacheDir(), fileName);
        try (FileOutputStream fos = new FileOutputStream(file)) {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            return file;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            if (photoFile != null) {
                photoUri = FileProvider.getUriForFile(this,
                        "com.example.birdtypedetection.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                mTakePhoto.launch(takePictureIntent);
            }
        }
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(imageFileName, ".jpg", storageDir);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setupComponents();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
